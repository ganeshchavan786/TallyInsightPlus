"""
Email Microservice
RabbitMQ Consumer for sending emails
"""

__version__ = "1.0.0"
