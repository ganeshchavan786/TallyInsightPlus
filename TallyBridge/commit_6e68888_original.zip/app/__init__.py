"""
Application Starter Kit
FastAPI MVC Backend Boilerplate
"""

__version__ = "1.0.0"
__author__ = "Starter Kit Team"
