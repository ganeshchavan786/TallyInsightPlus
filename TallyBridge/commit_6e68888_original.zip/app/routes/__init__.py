"""
Routes Package
API endpoints
"""

from app.routes import auth, company, user, permission, email
